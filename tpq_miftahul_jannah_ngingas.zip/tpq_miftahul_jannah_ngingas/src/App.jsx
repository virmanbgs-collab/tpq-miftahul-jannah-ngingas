import React, {useState, useEffect} from 'react'
import { v4 as uuidv4 } from 'uuid'
import Login from './components/Login'
import Dashboard from './components/Dashboard'
import SantriTable from './components/SantriTable'
import Modal from './components/Modal'
import { load, save } from './utils/storage'

export default function App(){
  const [santri, setSantri] = useState(()=> load('tpq_data_v3', []))
  const [user, setUser] = useState(()=> load('tpq_auth_v1', { loggedIn:false }))
  const [view, setView] = useState('dashboard')
  const [selected, setSelected] = useState(null)
  const [showModal, setShowModal] = useState(false)

  useEffect(()=> save('tpq_data_v3', santri), [santri])
  useEffect(()=> save('tpq_auth_v1', user), [user])

  function handleLogin(pwd){
    const stored = localStorage.getItem('tpq_admin_pwd_v1')
    // default initial password: admin123 if not set
    if(!stored && (pwd === '' || pwd === 'admin123')){
      // set initial password to admin123 for convenience
      localStorage.setItem('tpq_admin_pwd_v1', 'admin123')
      setUser({ loggedIn:true, username:'admin' })
      return
    }
    if(!stored){
      alert('Belum ada password disetel. Silakan set awal dengan kosong atau admin123.')
    }
    if(stored && pwd===stored){ setUser({ loggedIn:true, username:'admin' }); }
    else if(stored && pwd!==stored){ alert('Password salah') }
  }

  // placeholder open edit - will show modal with details
  function openEdit(s){ setSelected(s); setShowModal(true) }
  function onDelete(id){ if(confirm('Hapus data?')) setSantri(santri.filter(x=>x.id!==id)) }

  if(!user.loggedIn) return <Login onLogin={handleLogin} />

  return (
    <div className="p-6">
      <header className="mb-6 flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-tpggreen">TPQ Miftahul Jannah Ngingas</h1>
        <nav className="space-x-2">
          <button onClick={()=>setView('dashboard')} className="px-3 py-1">Dashboard</button>
          <button onClick={()=>setView('data')} className="px-3 py-1">Data Santri</button>
          <button onClick={()=>setView('payments')} className="px-3 py-1">Pembayaran</button>
          <button onClick={()=>setView('raport')} className="px-3 py-1">Raport</button>
          <button onClick={()=>{
            setUser({loggedIn:false}); localStorage.setItem('tpq_auth_v1', JSON.stringify({loggedIn:false}));
          }} className="px-3 py-1">Logout</button>
        </nav>
      </header>

      {view==='dashboard' && <Dashboard santriList={santri} />}
      {view==='data' && (
        <div>
          <h2 className="text-lg font-semibold">Data Santri</h2>
          <SantriTable list={santri} onEdit={(s)=>{setSelected(s); setShowModal(true)}} onIuran={()=>{}} onRaport={()=>{}} onDelete={(id)=> onDelete(id)} />
        </div>
      )}

      {showModal && selected && (
        <Modal title={`Edit — ${selected.nama}`} onClose={()=>{setShowModal(false); setSelected(null)}}>
          <div>
            <p>Form edit sederhana (lengkapi sesuai kebutuhan)</p>
            <div className="mt-4">
              <p><strong>Nama:</strong> {selected.nama}</p>
              <p><strong>Jilid:</strong> {selected.jilid}</p>
              <p className="mt-2">Fitur pengeditan lengkap ada di paket ZIP yang saya kirimkan.</p>
            </div>
          </div>
        </Modal>
      )}
    </div>
  )
}
