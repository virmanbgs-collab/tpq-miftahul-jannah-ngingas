TPQ Miftahul Jannah Ngingas — Aplikasi Database Santri & Iuran (React + Tailwind)

How to run locally:
1. npm install
2. npm run dev

How to deploy to Vercel:
1. Push this project to GitHub.
2. Login to vercel.com and import the repository.
3. Set Framework to "Vite" (auto-detected), build command: npm run build, output directory: dist.
4. Deploy.

Notes: data stored in browser localStorage. Use export CSV to backup.
